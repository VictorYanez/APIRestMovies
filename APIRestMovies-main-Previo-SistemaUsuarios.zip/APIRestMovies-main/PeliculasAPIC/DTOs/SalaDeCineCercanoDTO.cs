﻿namespace PeliculasAPIC.DTOs
{
    public class SalaDeCineCercanoDTO : SalaDeCineDTO
    {
        public double DistanciaEnMetros { get; set; }
    }
}
