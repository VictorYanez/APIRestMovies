﻿namespace PeliculasAPIC.Entidades
{
    public interface IId
    {
        public int Id { get; set; }
    }
}
