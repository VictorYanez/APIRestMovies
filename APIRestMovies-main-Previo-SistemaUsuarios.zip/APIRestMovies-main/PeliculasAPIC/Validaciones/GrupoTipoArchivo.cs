﻿namespace PeliculasAPIC.Validaciones
{
    public enum GrupoTipoArchivo
    {
        Imagen
    }
}
